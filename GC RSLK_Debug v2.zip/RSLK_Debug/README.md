## TI-RSLK Debug Application

Exercise basic robot functions using the GUI interface.

---

Each motor encoder should to be connected to the MSP432 as follows:

- Left Encoder A connected to P6.4 (J1)
- Left Encoder B connected to P6.5 (J1)
- Right Encoder A connected to P5.4 (J3)
- Right Encoder B connected to P5.5 (J3)
  
Pololu encoder has 12 counts per revolution (counting all 4 edges). The motor has a gearbox with a 120:1 ratio. This gives 12*120 = 1440 counts per revolution of the wheel. Since we are only counting one edge of the encoder we need to divide by 4 for a total of 360 counts per revolution.

