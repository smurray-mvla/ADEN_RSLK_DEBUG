
var logger1 = require("ti_logger")("C:/Users/me/company/app/log-config.json");

logger.info("info message"); //soiurce not included
logger.info('module1', "info message"); //source included