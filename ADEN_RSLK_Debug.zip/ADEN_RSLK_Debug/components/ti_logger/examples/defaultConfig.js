
var logger =  require("ti_logger");

logger.info("info message"); //soiurce not included
logger.info('module1', "info message"); //source included